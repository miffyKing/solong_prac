# Libft

## Your very first own library


Summary: This project aims to code a C library regrouping usual functions that you’ll
be use for all your next projects.

libft 정리 - [notion](https://iodized-sailfish-b0c.notion.site/Libft-465972716dbe4e8ebdce69962bc27265)
